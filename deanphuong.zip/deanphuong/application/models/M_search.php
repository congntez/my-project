<?php

/**
 * Created by IntelliJ IDEA.
 * User: phamtrong
 * Date: 14/06/16
 * Time: 15:33
 */
class M_search extends CI_Model {

    protected $_table = 'ion_groups';

}