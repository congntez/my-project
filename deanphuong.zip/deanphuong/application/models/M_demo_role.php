<?php

/**
 * Created by IntelliJ IDEA.
 * User: phamtrong
 * Date: 14/06/16
 * Time: 15:33
 */
class M_demo_role extends Crud_manager {

    protected $_table = 'ion_groups';

}