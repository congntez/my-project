<?php

class M_first_login extends Crud_model {
	public function __construct() {
		parent::__construct();

	}
	protected $_table = 'users';
}