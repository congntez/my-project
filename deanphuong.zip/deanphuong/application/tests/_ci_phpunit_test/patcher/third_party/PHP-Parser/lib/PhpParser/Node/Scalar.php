<?php

namespace PhpParser\Node;

abstract class Scalar extends Expr
{
}