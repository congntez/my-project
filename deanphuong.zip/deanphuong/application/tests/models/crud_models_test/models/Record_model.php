<?php

class Record_model extends Crud_model {
}