<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-21 14:15:22 --> Query error: Tablespace for table '`websitethanh`.`ci_migrations`' exists. Please DISCARD the tablespace before IMPORT. - Invalid query: CREATE TABLE IF NOT EXISTS `ci_migrations` (
	`version` BIGINT(20) NOT NULL
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2018-11-21 14:16:15 --> Query error: Tablespace for table '`websitethanh`.`ci_migrations`' exists. Please DISCARD the tablespace before IMPORT. - Invalid query: CREATE TABLE IF NOT EXISTS `ci_migrations` (
	`version` BIGINT(20) NOT NULL
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2018-11-21 14:29:59 --> Severity: Warning --> Illegal offset type in isset or empty E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\libraries\Session\Session.php 675
ERROR - 2018-11-21 14:30:50 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Login.php 46
ERROR - 2018-11-21 14:46:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 14:51:46 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 14:52:57 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 14:53:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 15:02:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 15:04:52 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 15:08:43 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 16:04:44 --> Severity: error --> Exception: Call to undefined function utf8convert() E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 88
ERROR - 2018-11-21 16:26:06 --> Severity: error --> Exception: syntax error, unexpected end of file E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\menu.php 202
ERROR - 2018-11-21 16:26:06 --> Severity: error --> Exception: syntax error, unexpected end of file E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\menu.php 202
ERROR - 2018-11-21 16:26:07 --> Severity: error --> Exception: syntax error, unexpected end of file E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\menu.php 202
ERROR - 2018-11-21 16:26:07 --> Severity: error --> Exception: syntax error, unexpected end of file E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\menu.php 202
ERROR - 2018-11-21 16:45:58 --> Severity: Notice --> Undefined property: stdClass::$view_home E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 87
ERROR - 2018-11-21 17:29:31 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 64
ERROR - 2018-11-21 17:29:31 --> Severity: error --> Exception: Call to undefined function utf8convert() E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 69
ERROR - 2018-11-21 17:30:16 --> Severity: error --> Exception: Call to undefined function utf8convert() E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 69
ERROR - 2018-11-21 17:30:28 --> Severity: error --> Exception: Call to undefined function utf8convert() E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 69
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:37:03 --> Severity: Notice --> Undefined property: stdClass::$convert_name E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 45
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:39:01 --> Severity: Warning --> Attempt to assign property 'convert_name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\All_collection.php 46
ERROR - 2018-11-21 17:40:58 --> Severity: error --> Exception: Call to undefined function utf_convert() E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 40
ERROR - 2018-11-21 17:41:59 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 35
ERROR - 2018-11-21 17:41:59 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 48
ERROR - 2018-11-21 17:41:59 --> Severity: Notice --> Undefined property: stdClass::$images3 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 53
ERROR - 2018-11-21 17:41:59 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 95
ERROR - 2018-11-21 17:43:18 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 35
ERROR - 2018-11-21 17:43:18 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 48
ERROR - 2018-11-21 17:43:18 --> Severity: Notice --> Undefined property: stdClass::$images3 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 53
ERROR - 2018-11-21 17:43:18 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 95
ERROR - 2018-11-21 17:43:34 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 35
ERROR - 2018-11-21 17:43:34 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 48
ERROR - 2018-11-21 17:43:34 --> Severity: Notice --> Undefined property: stdClass::$images3 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 53
ERROR - 2018-11-21 17:43:34 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 95
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 35
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 16
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 33
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Undefined property: stdClass::$images3 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 38
ERROR - 2018-11-21 17:44:59 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 80
ERROR - 2018-11-21 17:46:20 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 41
ERROR - 2018-11-21 17:46:20 --> Severity: Notice --> Undefined property: stdClass::$images2 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 33
ERROR - 2018-11-21 17:46:20 --> Severity: Notice --> Undefined property: stdClass::$images3 E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 38
ERROR - 2018-11-21 17:46:20 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 80
ERROR - 2018-11-21 17:46:55 --> Severity: Notice --> Undefined property: stdClass::$sup_id E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 41
ERROR - 2018-11-21 18:12:25 --> Severity: Notice --> Undefined index: size E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Home.php 80
ERROR - 2018-11-21 18:36:21 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:36:22 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\home.php 18
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Undefined variable: values E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:14 --> Severity: Notice --> Trying to get property 'count_prod' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:33 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:39:44 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:05 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:41:14 --> Severity: Notice --> Undefined property: stdClass::$count_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 20
ERROR - 2018-11-21 18:43:13 --> Severity: Notice --> Undefined variable: categories_prod E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 58
ERROR - 2018-11-21 18:43:13 --> Severity: Notice --> Trying to get property 'name' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 58
ERROR - 2018-11-21 19:20:20 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 19:26:14 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Register.php 48
ERROR - 2018-11-21 19:26:17 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Register.php 48
ERROR - 2018-11-21 19:35:18 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Home.php 92
ERROR - 2018-11-21 19:35:21 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Home.php 92
ERROR - 2018-11-21 19:44:05 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 19:45:21 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 19:52:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Security.php 354
ERROR - 2018-11-21 19:56:07 --> Severity: error --> Exception: syntax error, unexpected '=' E:\Xampp_7.2\htdocs\deanphuong\application\controller-layout\Admin_layout.php 36
ERROR - 2018-11-21 19:58:46 --> Severity: error --> Exception: Unable to locate the model you have specified: M_supplier_management E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Loader.php 348
ERROR - 2018-11-21 20:43:58 --> Severity: error --> Exception: Unable to locate the model you have specified: M_supplier_management E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Loader.php 348
ERROR - 2018-11-21 20:44:24 --> Severity: Notice --> Undefined property: Product_detail::$m_supplier_management E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 50
ERROR - 2018-11-21 20:44:24 --> Severity: error --> Exception: Call to a member function get_all() on null E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 50
ERROR - 2018-11-21 20:44:36 --> Severity: error --> Exception: Unable to locate the model you have specified: M_supplier_management E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Loader.php 348
ERROR - 2018-11-21 20:46:13 --> Severity: error --> Exception: Unable to locate the model you have specified: M_supplier_management E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\core\Loader.php 348
