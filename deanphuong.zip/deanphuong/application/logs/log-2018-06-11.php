<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-11 09:51:26 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 99
ERROR - 2018-06-11 09:51:35 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 99
ERROR - 2018-06-11 09:52:14 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 99
