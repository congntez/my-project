<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-28 06:05:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 68
ERROR - 2018-04-28 06:05:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 68
ERROR - 2018-04-28 06:05:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 69
ERROR - 2018-04-28 06:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 69
ERROR - 2018-04-28 06:08:10 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' E:\Xampp\htdocs\minhtrishop\application\controllers\Product_detail.php 23
ERROR - 2018-04-28 06:12:36 --> Severity: Notice --> Undefined property: stdClass::$supplier E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 86
ERROR - 2018-04-28 06:16:18 --> Severity: Notice --> Undefined property: stdClass::$descrition E:\Xampp\htdocs\minhtrishop\application\views\homepage\products_detail.php 92
ERROR - 2018-04-28 07:27:28 --> Severity: Parsing Error --> syntax error, unexpected end of file E:\Xampp\htdocs\minhtrishop\application\views\homepage\menu.php 141
ERROR - 2018-04-28 17:56:58 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Order.php 72
ERROR - 2018-04-28 17:56:58 --> Query error: Table 'triminhshop.user_book_tour' doesn't exist - Invalid query: INSERT INTO `user_book_tour` (`tour_id`, `tour_name`, `user_book_id`, `user_book_name`, `user_book_email`, `status`, `user_created_tour_id`) VALUES ('6', 'Kính thời trang  4', '1', 'congnt96', 'tiencong.ktqd@gmail.com', 'pending', NULL)
ERROR - 2018-04-28 19:00:15 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:15 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:15 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:17 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:17 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:17 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:18 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:18 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:18 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:19 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:19 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:19 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:47 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:47 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:47 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:48 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:48 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:49 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:49 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:49 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:49 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:49 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:49 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:50 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:50 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:51 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:51 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:51 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:52 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:52 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:52 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:53 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:53 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:53 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:53 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:00:53 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:00:53 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:01:04 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:01:04 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:01:04 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:01:04 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:03:01 --> Severity: Notice --> Undefined property: stdClass::$user_created_id E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 76
ERROR - 2018-04-28 19:03:01 --> Severity: Notice --> Undefined property: Home::$m_user_book_tour E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:03:01 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:04:57 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:15:33 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:15:33 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:15:33 --> Severity: Notice --> Undefined variable: tour_info E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 80
ERROR - 2018-04-28 19:15:33 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 80
ERROR - 2018-04-28 19:15:33 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 83
ERROR - 2018-04-28 19:15:33 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 83
ERROR - 2018-04-28 19:15:54 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:15:54 --> Severity: Notice --> Undefined variable: tour_info E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 80
ERROR - 2018-04-28 19:15:54 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 80
ERROR - 2018-04-28 19:15:54 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 83
ERROR - 2018-04-28 19:15:54 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 83
ERROR - 2018-04-28 19:17:11 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:17:11 --> Severity: Notice --> Undefined variable: tour_info E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:17:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:17:11 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 82
ERROR - 2018-04-28 19:17:11 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 82
ERROR - 2018-04-28 19:17:28 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:21:33 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:21:33 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:21:33 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:21:33 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:26:03 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:26:03 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:29:39 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 73
ERROR - 2018-04-28 19:29:39 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:29:39 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:29:39 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:30:47 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:30:47 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 75
ERROR - 2018-04-28 19:30:47 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:30:47 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 79
ERROR - 2018-04-28 19:31:06 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:31:06 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:31:06 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:31:15 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:31:15 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:31:15 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:34:13 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:34:13 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:34:13 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:34:34 --> Severity: Notice --> Undefined property: stdClass::$customer_phone E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 74
ERROR - 2018-04-28 19:34:34 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:34:34 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:35:01 --> Severity: Notice --> Undefined property: Home::$m_order E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:35:01 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 78
ERROR - 2018-04-28 19:35:27 --> Query error: Unknown column 'tour_id' in 'field list' - Invalid query: INSERT INTO `order` (`tour_id`, `prod_name`, `prod_code`, `count`, `customer_name`, `customer_phone`, `status`) VALUES ('6', 'Kính thời trang  4', 'TMK005', '1', 'admin', '', 'pending')
ERROR - 2018-04-28 19:55:55 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:56:44 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:56:57 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:57:32 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:57:34 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:58:02 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:59:00 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:59:13 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
ERROR - 2018-04-28 19:59:45 --> Severity: Notice --> Undefined index: count E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 58
