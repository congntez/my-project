<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-12 11:14:22 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 11:14:22 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 15:22:25 --> Query error: Table 'dean.product' doesn't exist - Invalid query: SELECT *
FROM `product` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-12 15:22:56 --> Query error: Table 'dean.place' doesn't exist - Invalid query: SELECT *
FROM `place` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-12 16:06:10 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:10 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:06:12 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:12 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:06:12 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:12 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:06:13 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:13 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:06:13 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:13 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:06:53 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:06:53 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:14:03 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:14:03 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:19:08 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:19:08 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:19:24 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:19:24 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:21:37 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:21:37 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:24:34 --> Severity: Notice --> Undefined property: stdClass::$parent_id E:\Xampp\htdocs\dean\application\controllers\admin\Demo_login.php 64
ERROR - 2017-12-12 16:35:29 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:35:29 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:35:48 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 314
ERROR - 2017-12-12 16:35:48 --> Severity: Notice --> A session had already been started - ignoring session_start() E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Session\Session.php 141
ERROR - 2017-12-12 16:36:45 --> Severity: error --> Exception: Undefined method Ion_auth::customer() called E:\Xampp\htdocs\dean\application\libraries\Ion_auth.php 100
ERROR - 2017-12-12 16:37:32 --> Severity: Notice --> Undefined property: Login::$m_login E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:37:32 --> Severity: Error --> Call to a member function customer() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:40:23 --> Severity: Error --> Call to undefined method M_login::customer() E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:43:55 --> Severity: Notice --> Undefined property: Login::$m_login E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:43:55 --> Severity: Error --> Call to a member function check_name() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:45:38 --> Severity: Notice --> Undefined property: Login::$m_login E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:45:38 --> Severity: Error --> Call to a member function check_name() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:49:01 --> Severity: Notice --> Undefined property: Login::$m_login E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:49:01 --> Severity: Error --> Call to a member function check_name() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 57
ERROR - 2017-12-12 16:50:15 --> Severity: Notice --> Undefined property: Login::$M_login E:\Xampp\htdocs\dean\application\controllers\Login.php 28
ERROR - 2017-12-12 16:50:15 --> Severity: Error --> Call to a member function check_name() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 28
ERROR - 2017-12-12 16:50:28 --> Severity: Notice --> Undefined property: Login::$M_login E:\Xampp\htdocs\dean\application\controllers\Login.php 28
ERROR - 2017-12-12 16:50:28 --> Severity: Error --> Call to a member function check_name() on null E:\Xampp\htdocs\dean\application\controllers\Login.php 28
ERROR - 2017-12-12 17:38:59 --> Severity: Notice --> Undefined index: username_sess E:\Xampp\htdocs\dean\application\views\homepage\menu.php 84
ERROR - 2017-12-12 17:39:13 --> Severity: Notice --> Undefined index: username_sess E:\Xampp\htdocs\dean\application\views\homepage\menu.php 84
ERROR - 2017-12-12 17:43:58 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' E:\Xampp\htdocs\dean\application\views\homepage\menu.php 84
ERROR - 2017-12-12 18:04:25 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' E:\Xampp\htdocs\dean\application\views\homepage\menu.php 86
ERROR - 2017-12-12 18:21:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 18:21:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 18:21:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 18:21:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 18:21:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-12 18:31:51 --> Query error: Unknown column 'images' in 'field list' - Invalid query: INSERT INTO `tour` (`name`, `lichkhoihanh`, `thoigian`, `diemthamquan`, `price`, `images`) VALUES ('DU LỊCH SAPA – HÀM RỒNG – CÁT CÁT – 2 NGÀY 1 ĐÊM ', 'Hàng ngày ', '2 Ngày 1 Đêm ', 'Núi Hàm Rồng - Bản Cát Cát - Shín Chải - Thị trấn Sapa ', '1,450,000 VNĐ', 'upload/tour/0e4f71e817b741a9749912230df5a909.jpg')
ERROR - 2017-12-12 18:31:54 --> Query error: Unknown column 'images' in 'field list' - Invalid query: INSERT INTO `tour` (`name`, `lichkhoihanh`, `thoigian`, `diemthamquan`, `price`, `images`) VALUES ('DU LỊCH SAPA – HÀM RỒNG – CÁT CÁT – 2 NGÀY 1 ĐÊM ', 'Hàng ngày ', '2 Ngày 1 Đêm ', 'Núi Hàm Rồng - Bản Cát Cát - Shín Chải - Thị trấn Sapa ', '1,450,000 VNĐ', 'upload/tour/3d0d413cf6f9c387032cd707c8c9c87a.jpg')
ERROR - 2017-12-12 18:32:34 --> Query error: Unknown column 'images' in 'field list' - Invalid query: INSERT INTO `tour` (`name`, `lichkhoihanh`, `thoigian`, `diemthamquan`, `price`, `images`) VALUES ('aaaaaa', 'aaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaaaaa', 'aaaaaaaaaaaaaa', 'upload/tour/ab667bd06ccba8c902d922fbb1246209.jpg')
ERROR - 2017-12-12 18:32:35 --> Query error: Unknown column 'images' in 'field list' - Invalid query: INSERT INTO `tour` (`name`, `lichkhoihanh`, `thoigian`, `diemthamquan`, `price`, `images`) VALUES ('aaaaaa', 'aaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaaaaa', 'aaaaaaaaaaaaaa', 'upload/tour/0ac882c4624180bffc64367b2b9909f2.jpg')
ERROR - 2017-12-12 18:36:26 --> Query error: Unknown column 'images' in 'field list' - Invalid query: INSERT INTO `tour` (`name`, `lichkhoihanh`, `thoigian`, `diemthamquan`, `price`, `images`) VALUES ('aaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaa', 'upload/tour/be7abe3dfa4e86d88b4b82937f7d2825.jpg')
ERROR - 2017-12-12 18:52:45 --> Severity: Notice --> Undefined property: Home::$m_tour_management E:\Xampp\htdocs\dean\application\controllers\Home.php 38
ERROR - 2017-12-12 18:52:45 --> Severity: Error --> Call to a member function get_all() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 38
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 57
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 57
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 65
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 65
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 72
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 72
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 73
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 73
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 74
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 74
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 76
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 76
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 57
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 57
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 65
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 65
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 72
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 72
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 73
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 73
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 74
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 74
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Undefined variable: test E:\Xampp\htdocs\dean\application\views\homepage\home.php 76
ERROR - 2017-12-12 18:53:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\home.php 76
