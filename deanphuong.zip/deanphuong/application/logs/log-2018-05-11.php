<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-11 17:18:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-11 17:18:17 --> Unable to connect to the database
ERROR - 2018-05-11 17:18:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-11 17:18:22 --> Unable to connect to the database
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$pro_price E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 59
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$pro_price E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 59
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
ERROR - 2018-05-11 17:48:09 --> Severity: Notice --> Undefined property: stdClass::$pro_price E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 59
ERROR - 2018-05-11 17:48:51 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
ERROR - 2018-05-11 17:48:51 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
ERROR - 2018-05-11 17:48:51 --> Severity: Notice --> Undefined property: stdClass::$code E:\Xampp\htdocs\minhtrishop\application\views\homepage\cart.php 56
