<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-12 17:38:11 --> Severity: Notice --> Undefined property: Search::$m_products_management E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 28
ERROR - 2018-06-12 17:38:11 --> Severity: Error --> Call to a member function get_search() on null E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 28
ERROR - 2018-06-12 17:39:07 --> Severity: Notice --> Undefined property: Search::$m_user_management E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 36
ERROR - 2018-06-12 17:39:07 --> Severity: Error --> Call to a member function get_by() on null E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 36
ERROR - 2018-06-12 17:39:19 --> Severity: Notice --> Undefined property: Search::$m_order E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 38
ERROR - 2018-06-12 17:39:19 --> Severity: Error --> Call to a member function get_many_by() on null E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 38
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:01:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:02:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:03:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 6
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Undefined index: images E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 10
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Undefined index: name E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 18
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Undefined index: price E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 25
ERROR - 2018-06-12 18:13:26 --> Severity: Notice --> Undefined index: old_price E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 25
ERROR - 2018-06-12 18:18:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 4
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:20:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 5
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:22:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 15
ERROR - 2018-06-12 18:29:26 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:29:27 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:29:34 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:30:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:30:15 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:30:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:30:29 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:30:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:30:35 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:30:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:30:50 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:31:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:31:43 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:31:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:31:46 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:31:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:31:57 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:32:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:35) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:32:12 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:32:58 --> Severity: Notice --> Undefined index: result E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 33
ERROR - 2018-06-12 18:32:58 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:33:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:33) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:33:08 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:33:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:33) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:33:36 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:33:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\controllers\Search.php:33) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-12 18:33:38 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:38:18 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
ERROR - 2018-06-12 18:38:39 --> Severity: Error --> Cannot use object of type stdClass as array E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 12
