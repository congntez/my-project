<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Undefined variable: place_detail E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 9
ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 9
ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Undefined variable: place_detail E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 12
ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 12
ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Undefined variable: place_detail E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 16
ERROR - 2017-12-24 03:47:33 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 16
ERROR - 2017-12-24 04:11:00 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 27
ERROR - 2017-12-24 04:16:13 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 30
ERROR - 2017-12-24 04:19:15 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 30
ERROR - 2017-12-24 04:28:11 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 29
ERROR - 2017-12-24 04:28:11 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\homepage\tour\detail.php 30
