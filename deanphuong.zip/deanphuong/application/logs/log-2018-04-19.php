<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-19 17:39:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-04-19 17:39:52 --> Unable to connect to the database
