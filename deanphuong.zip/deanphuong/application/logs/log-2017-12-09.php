<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-09 05:53:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'travel' E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-12-09 05:53:28 --> Unable to connect to the database
ERROR - 2017-12-09 05:53:40 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'travel' E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-12-09 05:53:40 --> Unable to connect to the database
ERROR - 2017-12-09 07:18:49 --> Severity: Error --> Class 'Homepage_layout' not found E:\Xampp\htdocs\dean\application\controllers\Home.php 3
ERROR - 2017-12-09 07:19:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'travel' E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-12-09 07:19:30 --> Unable to connect to the database
ERROR - 2017-12-09 07:19:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1044): Access denied for user ''@'localhost' to database 'travel' E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-12-09 07:19:49 --> Unable to connect to the database
ERROR - 2017-12-09 07:26:58 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\Xampp\htdocs\dean\application\controllers\User_management.php 14
ERROR - 2017-12-09 08:05:02 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 10:25:00 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 10:25:07 --> Severity: error --> Exception: ['form']['callback_render_html'] of 'password'(function 'custom_render_password') 
                    does not exist at both controller (user_management) and model (m_user_management)! E:\Xampp\htdocs\dean\application\controller-manager\Manager_base.php 597
ERROR - 2017-12-09 10:25:07 --> Severity: error --> Exception: ['form']['callback_render_html'] of 'password'(function 'custom_render_password') 
                    does not exist at both controller (user_management) and model (m_user_management)! E:\Xampp\htdocs\dean\application\controller-manager\Manager_base.php 597
ERROR - 2017-12-09 10:25:10 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 10:26:09 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 10:26:12 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 10:26:22 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:45:10 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:51:30 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:51:43 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:52:35 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:53:12 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 15:56:07 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
JOIN `ion_users_groups` as `ug` ON `m`.`id`=`ug`.`user_id`
JOIN `ion_groups` as `g` ON `ug`.`group_id`=`g`.`id`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 17:24:55 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_user_management' does not have a method 'join_role_table' E:\Xampp\htdocs\dean\application\model-crud\Crud_model.php 722
ERROR - 2017-12-09 17:24:55 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 17:25:05 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_user_management' does not have a method 'join_role_table' E:\Xampp\htdocs\dean\application\model-crud\Crud_model.php 722
ERROR - 2017-12-09 17:25:05 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 17:25:21 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 17:25:34 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 17:27:00 --> Severity: error --> Exception: ['table']['callback_render_data'] of 'email'(function 'add_link') 
                            does not exist at both controller (user_management) and model (m_user_management)! E:\Xampp\htdocs\dean\application\controller-manager\Manager_base.php 419
ERROR - 2017-12-09 17:28:18 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-09 17:31:01 --> Query error: Unknown column 'g.id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `users` AS `m`
WHERE `g`.`id` = '1'
AND `m`.`deleted` =0
ERROR - 2017-12-09 17:32:01 --> Severity: error --> Exception: Filter type 'select' must be have 'target_model' and 'target_function' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 366
ERROR - 2017-12-09 18:03:23 --> Query error: Table 'travel.place' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `place` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 18:03:38 --> Query error: Table 'travel.place' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `place` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 18:04:03 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 18:04:23 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 18:04:33 --> Query error: Unknown column 'm.deleted' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-09 18:04:52 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:05:08 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:05:14 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:05:42 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:05:47 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:05:55 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:06:53 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:06:57 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:09:17 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:09:21 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:09:47 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:09:48 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:09:51 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:10:28 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:10:35 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:12:16 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `places` (`name`, `description`) VALUES ('Đèo pha đin', 'đẹp vãi cả đái')
ERROR - 2017-12-09 18:14:09 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:16:20 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:19:16 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:19:30 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:19:46 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:20:02 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:21:12 --> Query error: Unknown column 'm.id' in 'order clause' - Invalid query: SELECT *
FROM `places` AS `m`
WHERE `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2017-12-09 18:25:06 --> Severity: Notice --> Undefined property: stdClass::$place_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
