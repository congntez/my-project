<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-07 18:21:01 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:21:01 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:21:01 --> Severity: Notice --> Undefined variable: categories E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 33
ERROR - 2018-06-07 18:21:01 --> Severity: Notice --> Undefined variable: manufacturer E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 34
ERROR - 2018-06-07 18:21:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0' at line 4 - Invalid query: SELECT *
FROM `products` AS `m`
WHERE `cat_id` IS NULL
AND  IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0
ERROR - 2018-06-07 18:22:34 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:22:34 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:22:34 --> Severity: Notice --> Undefined variable: categories E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 37
ERROR - 2018-06-07 18:22:34 --> Severity: Notice --> Undefined variable: manufacturer E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 38
ERROR - 2018-06-07 18:22:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0' at line 4 - Invalid query: SELECT *
FROM `products` AS `m`
WHERE `cat_id` IS NULL
AND  IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0
ERROR - 2018-06-07 18:22:35 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:22:35 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:22:35 --> Severity: Notice --> Undefined variable: categories E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 37
ERROR - 2018-06-07 18:22:35 --> Severity: Notice --> Undefined variable: manufacturer E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 38
ERROR - 2018-06-07 18:22:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0' at line 4 - Invalid query: SELECT *
FROM `products` AS `m`
WHERE `cat_id` IS NULL
AND  IS NULL
AND `sup_id` IS NULL
AND  IS NULL
AND `m`.`deleted` =0
ERROR - 2018-06-07 18:22:57 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:22:57 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:23:25 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:23:25 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:24:11 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:24:11 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:32:42 --> Severity: Warning --> Missing argument 1 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:32:42 --> Severity: Warning --> Missing argument 2 for All_collection::index() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:32:42 --> Severity: Notice --> Undefined variable: categories E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 37
ERROR - 2018-06-07 18:32:42 --> Severity: Notice --> Undefined variable: manufacturer E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 38
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:06 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:09 --> Severity: Notice --> Undefined property: stdClass::$ids E:\Xampp\htdocs\websitethanh\application\views\homepage\home.php 15
ERROR - 2018-06-07 18:40:27 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:41:31 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:41:49 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:42:39 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:43:30 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 18:43:35 --> Severity: Warning --> Missing argument 2 for All_collection::view() E:\Xampp\htdocs\websitethanh\application\controllers\All_collection.php 26
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:07:57 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:09:02 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\glasses.php 80
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:16:20 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:17:52 --> Severity: Notice --> Undefined index: cat_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 13
ERROR - 2018-06-07 19:19:48 --> Severity: Parsing Error --> syntax error, unexpected end of file E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 215
ERROR - 2018-06-07 19:20:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:17 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:18 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Undefined variable: values_product E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:20:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:21:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:22 --> Severity: Notice --> Undefined variable: sup_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:41 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:30:45 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:41:55 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:23 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:44:24 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:04 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:09 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:54 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:58 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:46:59 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 19:47:50 --> Severity: Notice --> Undefined variable: supply_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 28
ERROR - 2018-06-07 20:00:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:00:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:00:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:00:04 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:00:05 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:00:05 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:03:56 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 80
ERROR - 2018-06-07 20:10:39 --> Severity: Warning --> strtolower() expects parameter 1 to be string, array given E:\Xampp\htdocs\websitethanh\vendor\hamcrest\hamcrest-php\hamcrest\Hamcrest\Core\IsTypeOf.php 26
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:01 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:02 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 17
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
ERROR - 2018-06-07 20:20:47 --> Severity: Notice --> Undefined variable: categories_id E:\Xampp\htdocs\websitethanh\application\views\homepage\all_collection.php 16
