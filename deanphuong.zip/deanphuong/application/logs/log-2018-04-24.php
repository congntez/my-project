<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-24 03:57:27 --> Severity: Warning --> array_merge(): Argument #1 is not an array E:\Xampp\htdocs\minhtrishop\application\controllers\Glasses.php 32
ERROR - 2018-04-24 03:57:27 --> Severity: Warning --> array_merge(): Argument #1 is not an array E:\Xampp\htdocs\minhtrishop\application\controllers\Glasses.php 32
