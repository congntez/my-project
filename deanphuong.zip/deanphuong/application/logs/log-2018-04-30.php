<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-30 16:09:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-30 16:09:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-04-30 16:09:06 --> Unable to connect to the database
ERROR - 2018-04-30 16:09:06 --> Unable to connect to the database
ERROR - 2018-04-30 16:55:38 --> Severity: Error --> Call to undefined function money_format() E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 69
ERROR - 2018-04-30 16:55:41 --> Severity: Error --> Call to undefined function money_format() E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 69
ERROR - 2018-04-30 16:55:50 --> Severity: Error --> Call to undefined function money_format() E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 69
