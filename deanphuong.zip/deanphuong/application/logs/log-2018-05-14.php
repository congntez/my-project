<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-14 17:25:45 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 54
ERROR - 2018-05-14 17:25:55 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 54
ERROR - 2018-05-14 17:26:20 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 51
ERROR - 2018-05-14 17:26:23 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 51
ERROR - 2018-05-14 17:26:23 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 51
ERROR - 2018-05-14 17:26:23 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 51
ERROR - 2018-05-14 17:26:24 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 51
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Notice --> A non well formed numeric value encountered E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 75
ERROR - 2018-05-14 17:36:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 88
ERROR - 2018-05-14 17:36:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 89
ERROR - 2018-05-14 17:36:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\minhtrishop\application\libraries\Excel_lib.php 90
ERROR - 2018-05-14 17:46:12 --> Severity: error --> Exception: Cell coordinate can not be a range of cells. E:\Xampp\htdocs\minhtrishop\application\third_party\PHPExcel\PHPExcel\Worksheet.php 1180
ERROR - 2018-05-14 17:46:27 --> Severity: error --> Exception: Cell coordinate can not be a range of cells. E:\Xampp\htdocs\minhtrishop\application\third_party\PHPExcel\PHPExcel\Worksheet.php 1180
