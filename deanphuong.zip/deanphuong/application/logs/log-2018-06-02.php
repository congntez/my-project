<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-02 17:16:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:16:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:16:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:16:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:20:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:20:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:20:43 --> Severity: Error --> Call to undefined method M_products_management::like() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 30
ERROR - 2018-06-02 17:25:32 --> Severity: Error --> Call to undefined method M_products_management::get_search() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 30
ERROR - 2018-06-02 17:26:39 --> Severity: Error --> Call to undefined method M_products_management::get_search() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 17:27:50 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:27:50 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:27:50 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:28:48 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:28:48 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:28:48 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:30:34 --> Severity: Warning --> Missing argument 1 for M_products_management::get_search(), called in E:\Xampp\htdocs\websitethanh\application\controllers\Search.php on line 28 and defined E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 212
ERROR - 2018-06-02 17:30:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 213
ERROR - 2018-06-02 17:30:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 214
ERROR - 2018-06-02 17:30:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 215
ERROR - 2018-06-02 17:31:34 --> Severity: Warning --> Missing argument 1 for M_products_management::get_search(), called in E:\Xampp\htdocs\websitethanh\application\controllers\Search.php on line 28 and defined E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 212
ERROR - 2018-06-02 17:31:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 213
ERROR - 2018-06-02 17:31:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 214
ERROR - 2018-06-02 17:31:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 215
ERROR - 2018-06-02 17:31:34 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 216
ERROR - 2018-06-02 17:31:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-02 17:31:37 --> Severity: Warning --> Missing argument 1 for M_products_management::get_search(), called in E:\Xampp\htdocs\websitethanh\application\controllers\Search.php on line 28 and defined E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 212
ERROR - 2018-06-02 17:31:37 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 213
ERROR - 2018-06-02 17:31:37 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 214
ERROR - 2018-06-02 17:31:37 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 215
ERROR - 2018-06-02 17:31:37 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 216
ERROR - 2018-06-02 17:31:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-02 17:31:49 --> Severity: Warning --> Missing argument 1 for M_products_management::get_search(), called in E:\Xampp\htdocs\websitethanh\application\controllers\Search.php on line 28 and defined E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 212
ERROR - 2018-06-02 17:31:49 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 213
ERROR - 2018-06-02 17:31:49 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 214
ERROR - 2018-06-02 17:31:49 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 215
ERROR - 2018-06-02 17:31:50 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 216
ERROR - 2018-06-02 17:31:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-02 17:34:25 --> Severity: Warning --> Missing argument 1 for M_products_management::get_search(), called in E:\Xampp\htdocs\websitethanh\application\controllers\Search.php on line 28 and defined E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 212
ERROR - 2018-06-02 17:34:25 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 214
ERROR - 2018-06-02 17:34:25 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 215
ERROR - 2018-06-02 17:34:25 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 216
ERROR - 2018-06-02 17:34:25 --> Severity: Notice --> Undefined variable: search E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php 217
ERROR - 2018-06-02 17:34:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Exceptions.php:272) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-02 17:35:21 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:35:21 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:35:21 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:36:06 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:36:07 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:36:07 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:04 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:04 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:04 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:28 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:28 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:37:28 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:44:33 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:44:33 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:44:33 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:46:39 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:46:39 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:46:39 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:46:39 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:46:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\Xampp\htdocs\websitethanh\application\models\M_products_management.php:215) E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\core\Common.php 573
ERROR - 2018-06-02 17:51:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:51:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:51:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:52:18 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:31 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:31 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 17:53:31 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:00:16 --> Severity: Notice --> Undefined property: Search::$model E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:00:16 --> Severity: Error --> Call to a member function ajax_list_data() on null E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:01:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:01:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:01:03 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:09:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:09:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:09:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:09:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:09:53 --> Query error: Unknown column 'username' in 'where clause' - Invalid query: SELECT *
FROM `products`
WHERE `username` LIKE '%Array%' ESCAPE '!'
OR  `name` LIKE '%Array%' ESCAPE '!'
OR  `description` LIKE '%Array%' ESCAPE '!'
OR  `price` LIKE '%Array%' ESCAPE '!'
ERROR - 2018-06-02 18:11:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:12:34 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:12:36 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:12:37 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:12:37 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:17:49 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:20:43 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:22:37 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:22:37 --> Severity: Notice --> Undefined variable: link_login E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 66
ERROR - 2018-06-02 18:22:37 --> Severity: Notice --> Undefined variable: link_login E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 149
ERROR - 2018-06-02 18:23:56 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:23:56 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:24:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:24:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:24:48 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:24:48 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:26:01 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:26:15 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:29:47 --> Severity: Notice --> Undefined property: Search::$m_search E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 30
ERROR - 2018-06-02 18:29:47 --> Severity: Error --> Call to a member function get_search() on null E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 30
ERROR - 2018-06-02 18:30:40 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:31:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\DB_query_builder.php 965
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:35:29 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 32
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:39:21 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 31
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:42 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:50:57 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 3
ERROR - 2018-06-02 18:51:47 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 2
ERROR - 2018-06-02 18:52:56 --> Severity: Warning --> Missing argument 1 for Search::index() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 24
ERROR - 2018-06-02 18:52:56 --> Severity: Notice --> Undefined variable: result E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 2
ERROR - 2018-06-02 18:53:25 --> Severity: Warning --> Missing argument 1 for Search::index() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 24
ERROR - 2018-06-02 18:53:51 --> Severity: Warning --> Missing argument 1 for Search::index() E:\Xampp\htdocs\websitethanh\application\controllers\Search.php 24
ERROR - 2018-06-02 18:57:47 --> Severity: Notice --> Undefined variable: result E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 2
ERROR - 2018-06-02 18:57:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 2
ERROR - 2018-06-02 19:01:54 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 1
ERROR - 2018-06-02 19:02:22 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 1
ERROR - 2018-06-02 19:03:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 1
ERROR - 2018-06-02 19:03:30 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 1
ERROR - 2018-06-02 19:09:09 --> Severity: Notice --> Undefined variable: footer E:\Xampp\htdocs\websitethanh\application\views\homepage\search.php 11
ERROR - 2018-06-02 19:16:21 --> Severity: Notice --> Undefined variable: result E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:24 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:26 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:26 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:26 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:26 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:26 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
ERROR - 2018-06-02 19:16:27 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 177
