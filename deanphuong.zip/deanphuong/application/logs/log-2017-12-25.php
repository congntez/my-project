<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-25 14:39:53 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:39:54 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:39:55 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:39:55 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:39:55 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:01 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:23 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:24 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:24 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:28 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:28 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:28 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:28 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:28 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:34 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:34 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:41 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:41:43 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:42:16 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:42:16 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:42:17 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 14:42:20 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$result E:\Xampp\htdocs\dean\application\models\M_login.php 47
ERROR - 2017-12-25 15:33:27 --> Severity: Error --> Call to undefined function json_endcode() E:\Xampp\htdocs\dean\application\controllers\Login.php 88
ERROR - 2017-12-25 15:58:45 --> Severity: Notice --> Undefined variable: user E:\Xampp\htdocs\dean\application\views\homepage\menu.php 78
ERROR - 2017-12-25 16:35:11 --> Severity: Notice --> Undefined variable: menu_data E:\Xampp\htdocs\dean\application\views\admin\base_layout\side_bar_left.php 66
ERROR - 2017-12-25 16:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_layout\side_bar_left.php 41
