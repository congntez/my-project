<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-15 10:41:36 --> Severity: error --> Exception: E:\Xampp\htdocs\minhtrishop\application\models/M_categories_management.php exists, but doesn't declare class M_categories_management E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\core\Loader.php 336
ERROR - 2018-04-15 11:14:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 28
ERROR - 2018-04-15 11:14:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 29
ERROR - 2018-04-15 11:14:44 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 29
ERROR - 2018-04-15 11:17:05 --> Severity: Notice --> Undefined offset: 1 E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_model.php 821
ERROR - 2018-04-15 11:17:05 --> Severity: Notice --> Undefined offset: 0 E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_model.php 824
ERROR - 2018-04-15 11:17:05 --> Severity: Notice --> Undefined offset: 1 E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_model.php 824
ERROR - 2018-04-15 11:17:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 4 - Invalid query: SELECT *
FROM `categories` AS `m`
WHERE `m`.`deleted` =0
AND `m`. IS NULL
ERROR - 2018-04-15 11:59:37 --> Severity: Runtime Notice --> Declaration of Products_management::index() should be compatible with Manager_base::index() E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 9
ERROR - 2018-04-15 11:59:37 --> Severity: Warning --> Missing argument 1 for Products_management::index() E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 25
ERROR - 2018-04-15 11:59:37 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 28
ERROR - 2018-04-15 11:59:37 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 29
ERROR - 2018-04-15 11:59:58 --> Severity: Runtime Notice --> Declaration of Products_management::index() should be compatible with Manager_base::index() E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 9
ERROR - 2018-04-15 11:59:58 --> Severity: Warning --> Missing argument 1 for Products_management::index() E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 25
ERROR - 2018-04-15 11:59:58 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 28
ERROR - 2018-04-15 12:10:47 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 29
ERROR - 2018-04-15 12:12:05 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_products_management' does not have a method 'get_data_categories' E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_manager.php 375
ERROR - 2018-04-15 12:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-04-15 12:15:45 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 29
ERROR - 2018-04-15 12:21:36 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_products_management' does not have a method 'get_cat_name' E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_manager.php 375
ERROR - 2018-04-15 12:21:36 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_products_management' does not have a method 'get_cat_name' E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_manager.php 375
ERROR - 2018-04-15 12:21:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-04-15 12:21:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-04-15 12:22:55 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_products_management' does not have a method 'get_cat_name' E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_manager.php 375
ERROR - 2018-04-15 12:22:55 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_products_management' does not have a method 'get_cat_name' E:\Xampp\htdocs\minhtrishop\application\model-crud\Crud_manager.php 375
ERROR - 2018-04-15 12:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-04-15 12:22:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\form_item.php 20
