<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-15 07:38:25 --> Severity: Notice --> Undefined variable: export_order E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 26
ERROR - 2018-05-15 07:38:42 --> Severity: Notice --> Undefined variable: export_order E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 26
ERROR - 2018-05-15 07:39:06 --> Severity: Notice --> Undefined variable: export_order E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 26
ERROR - 2018-05-15 07:43:52 --> Severity: Notice --> Undefined variable: export_order E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 23
ERROR - 2018-05-15 07:43:52 --> Severity: Notice --> Undefined variable: export_order E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 26
ERROR - 2018-05-15 07:47:54 --> Severity: Notice --> Undefined variable: export_product E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_header.php 26
ERROR - 2018-05-15 07:58:05 --> Severity: Notice --> Undefined property: Products_management::$excel_lib E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 37
ERROR - 2018-05-15 07:58:05 --> Severity: Error --> Call to a member function _export_product() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Products_management.php 37
