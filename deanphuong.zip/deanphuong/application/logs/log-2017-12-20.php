<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-20 16:12:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-12-20 16:12:58 --> Unable to connect to the database
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:02:45 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:03:37 --> Severity: error --> Exception: Filter type 'select' must be have 'target_model' and 'target_function' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 366
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:07 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:04:46 --> Severity: Notice --> Undefined property: stdClass::$role_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:06:54 --> Severity: Notice --> Undefined property: stdClass::$note E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-20 17:16:12 --> Query error: Table 'dean.room' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `room` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-20 17:16:19 --> Query error: Table 'dean.room' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `room` AS `m`
WHERE `m`.`deleted` =0
