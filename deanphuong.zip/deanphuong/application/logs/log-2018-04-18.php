<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-18 13:17:57 --> Query error: Table 'triminhshop.tour' doesn't exist - Invalid query: SELECT *
FROM `tour` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2018-04-18 13:18:10 --> Query error: Table 'triminhshop.tour' doesn't exist - Invalid query: SELECT *
FROM `tour` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2018-04-18 13:18:31 --> Query error: Table 'triminhshop.tour' doesn't exist - Invalid query: SELECT *
FROM `tour` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2018-04-18 13:18:59 --> Query error: Table 'triminhshop.tour' doesn't exist - Invalid query: SELECT *
FROM `tour` AS `m`
WHERE `m`.`deleted` =0
