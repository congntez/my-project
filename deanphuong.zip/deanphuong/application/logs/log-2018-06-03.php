<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-03 08:11:25 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 33
ERROR - 2018-06-03 08:11:25 --> Severity: Error --> Call to a member function get_by() on null E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 33
ERROR - 2018-06-03 08:11:46 --> Severity: Notice --> Undefined index: user E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 36
ERROR - 2018-06-03 08:11:46 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 36
ERROR - 2018-06-03 08:12:01 --> Severity: Notice --> Undefined index: user E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 36
ERROR - 2018-06-03 08:12:01 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 36
ERROR - 2018-06-03 08:12:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 36
ERROR - 2018-06-03 08:12:44 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 37
ERROR - 2018-06-03 08:21:37 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 08:22:50 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 08:22:53 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 08:26:53 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 08:27:15 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 09:27:02 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 09:53:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 68
ERROR - 2018-06-03 09:53:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:53:18 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 68
ERROR - 2018-06-03 09:53:18 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:54:21 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 68
ERROR - 2018-06-03 09:54:21 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:55:37 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:55:37 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:39 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:39 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:41 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:41 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:42 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:45 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:46 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:46 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:46 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:46 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:56:48 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:56:49 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:11 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:11 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:11 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:11 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:12 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: address E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 69
ERROR - 2018-06-03 09:57:13 --> Severity: Notice --> Undefined index: phone E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 70
ERROR - 2018-06-03 09:59:26 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 10:33:42 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:36:27 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:36:29 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:36:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:37:02 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:37:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:37:51 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 32
ERROR - 2018-06-03 10:38:24 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 10:40:04 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 10:40:37 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 11:08:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:08:54 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:09:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:09:28 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:09:59 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:10:05 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Product_detail.php 52
ERROR - 2018-06-03 11:10:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 92
ERROR - 2018-06-03 11:10:15 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 92
ERROR - 2018-06-03 11:10:38 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Product_detail.php 52
ERROR - 2018-06-03 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:11:36 --> Severity: Notice --> Undefined variable: count_cart E:\Xampp\htdocs\websitethanh\application\views\homepage\menu.php 40
ERROR - 2018-06-03 11:13:00 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:13:47 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 39
ERROR - 2018-06-03 11:15:47 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:31 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:32 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:32 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:32 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:32 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:16:32 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
ERROR - 2018-06-03 11:17:19 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Home.php 40
