<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-04 01:56:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 29
ERROR - 2018-01-04 01:56:58 --> Severity: Error --> Call to a member function insert_user() on null E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 29
ERROR - 2018-01-04 01:58:15 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 01:58:15 --> Severity: Error --> Call to a member function insert_data() on null E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 01:59:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 01:59:13 --> Severity: Error --> Call to a member function insert_data() on null E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 02:00:40 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 02:00:40 --> Severity: Error --> Call to a member function insert_data() on null E:\Xampp\htdocs\dean\application\controllers\Login_first\Form_place.php 30
ERROR - 2018-01-04 05:10:17 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:10:17 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:10:21 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:10:21 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:10:55 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:10:55 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 24
ERROR - 2018-01-04 05:11:22 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 32
ERROR - 2018-01-04 05:12:18 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\homepage\place\detail.php 12
ERROR - 2018-01-04 05:12:18 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\views\homepage\place\detail.php 16
ERROR - 2018-01-04 05:12:54 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:12:54 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:12:57 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:12:57 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:13:14 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:13:14 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:13:26 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:13:26 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:14:45 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 142
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:07 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:16 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:40 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 116
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_place_management.php 107
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 05:16:52 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-01-04 16:22:42 --> Severity: Warning --> Missing argument 1 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:22:42 --> Severity: Warning --> Missing argument 2 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:22:42 --> Severity: Notice --> Undefined variable: part E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 172
ERROR - 2018-01-04 16:22:42 --> Severity: error --> Exception: Invalid param, part name must be "string" ! E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 254
ERROR - 2018-01-04 16:23:09 --> Severity: Warning --> Missing argument 1 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:09 --> Severity: Warning --> Missing argument 2 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:09 --> Severity: Notice --> Undefined variable: part E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 172
ERROR - 2018-01-04 16:23:09 --> Severity: error --> Exception: Invalid param, part name must be "string" ! E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 254
ERROR - 2018-01-04 16:23:10 --> Severity: Warning --> Missing argument 1 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:10 --> Severity: Warning --> Missing argument 2 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:10 --> Severity: Notice --> Undefined variable: part E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 172
ERROR - 2018-01-04 16:23:10 --> Severity: error --> Exception: Invalid param, part name must be "string" ! E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 254
ERROR - 2018-01-04 16:23:16 --> Severity: Warning --> Missing argument 1 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:16 --> Severity: Warning --> Missing argument 2 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:16 --> Severity: Notice --> Undefined variable: part E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 172
ERROR - 2018-01-04 16:23:16 --> Severity: error --> Exception: Invalid param, part name must be "string" ! E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 254
ERROR - 2018-01-04 16:23:31 --> Severity: Warning --> Missing argument 2 for Base_layout::set_data_part(), called in E:\Xampp\htdocs\dean\application\controllers\User_profile.php on line 8 and defined E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 171
ERROR - 2018-01-04 16:23:31 --> Severity: error --> Exception: Part 'side_bar' not exist! E:\Xampp\htdocs\dean\application\controller-layout\Base_layout.php 258
