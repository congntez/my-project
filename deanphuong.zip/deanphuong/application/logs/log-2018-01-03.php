<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_created_tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_created_tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_created_tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$user_created_tour_id E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 14:29:56 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2018-01-03 15:21:45 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_tour_book' does not have a method 'get_status' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 375
ERROR - 2018-01-03 15:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 15:22:06 --> Severity: error --> Exception: Filter type 'select' must be have 'target_model' and 'target_function' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 366
ERROR - 2018-01-03 15:22:06 --> Severity: error --> Exception: Filter type 'select' must be have 'target_model' and 'target_function' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 366
ERROR - 2018-01-03 15:22:21 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'M_tour_book' does not have a method 'get_status' E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 375
ERROR - 2018-01-03 15:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 15:35:41 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:41 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:43 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:43 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:44 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:44 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:44 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:44 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:45 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:35:45 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:37:37 --> Severity: Notice --> Undefined property: Home::$m_user_management E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:37:37 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2018-01-03 15:38:04 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Home.php 101
ERROR - 2018-01-03 15:38:08 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Home.php 101
ERROR - 2018-01-03 15:38:13 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Home.php 101
ERROR - 2018-01-03 15:51:19 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:22 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:24 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:31 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:32 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:32 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:32 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:33 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:33 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:33 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:33 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:33 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:34 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:39 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:40 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:40 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 15:51:40 --> Severity: Notice --> Undefined index: email E:\Xampp\htdocs\dean\application\controllers\Login.php 31
ERROR - 2018-01-03 16:15:49 --> Query error: Table 'dean.user_room_tour' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user_room_tour` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2018-01-03 16:16:29 --> Query error: Unknown column 'user_created_tour_id' in 'where clause' - Invalid query: SELECT *
FROM `user_book_room` AS `m`
WHERE `user_created_tour_id` = '12'
AND `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2018-01-03 16:17:03 --> Query error: Unknown column 'user_created_tour_id' in 'where clause' - Invalid query: SELECT *
FROM `user_book_room` AS `m`
WHERE `user_created_tour_id` = '12'
AND `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2018-01-03 16:17:05 --> Query error: Unknown column 'user_created_tour_id' in 'where clause' - Invalid query: SELECT *
FROM `user_book_room` AS `m`
WHERE `user_created_tour_id` = '12'
AND `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2018-01-03 16:17:34 --> Query error: Unknown column 'user_created_tour_id' in 'where clause' - Invalid query: SELECT *
FROM `user_book_room` AS `m`
WHERE `user_created_tour_id` = '12'
AND `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2018-01-03 16:18:25 --> Query error: Unknown column 'user_created_tour_id' in 'where clause' - Invalid query: SELECT *
FROM `user_book_room` AS `m`
WHERE `user_created_tour_id` = '12'
AND `m`.`deleted` =0
ORDER BY `m`.`id` DESC
 LIMIT 20
ERROR - 2018-01-03 16:19:13 --> Severity: Notice --> Undefined property: Hotel::$m_user_book_room E:\Xampp\htdocs\dean\application\controllers\Hotel.php 85
ERROR - 2018-01-03 16:19:13 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\dean\application\controllers\Hotel.php 85
ERROR - 2018-01-03 16:20:04 --> Severity: error --> Exception: Unable to locate the model you have specified: M_user_book_room E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\core\Loader.php 344
ERROR - 2018-01-03 16:20:52 --> Severity: Notice --> Undefined property: Hotel::$m_user_book_room E:\Xampp\htdocs\dean\application\controllers\Hotel.php 85
ERROR - 2018-01-03 16:20:52 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\dean\application\controllers\Hotel.php 85
ERROR - 2018-01-03 16:21:17 --> Query error: Unknown column 'tour_id' in 'field list' - Invalid query: INSERT INTO `user_book_room` (`tour_id`, `tour_name`, `user_book_id`, `user_book_name`, `user_book_email`, `status`, `user_created_tour_id`) VALUES ('1', 'Khách sạn Amazing Sapa', '1', 'congnt96', 'tiencong.ktqd@gmail.com', 'pending', '12')
ERROR - 2018-01-03 16:21:19 --> Query error: Unknown column 'tour_id' in 'field list' - Invalid query: INSERT INTO `user_book_room` (`tour_id`, `tour_name`, `user_book_id`, `user_book_name`, `user_book_email`, `status`, `user_created_tour_id`) VALUES ('1', 'Khách sạn Amazing Sapa', '1', 'congnt96', 'tiencong.ktqd@gmail.com', 'pending', '12')
ERROR - 2018-01-03 16:21:44 --> Query error: Unknown column 'user_created_tour_id' in 'field list' - Invalid query: INSERT INTO `user_book_room` (`room_id`, `hotel_name`, `user_book_id`, `user_book_name`, `user_book_email`, `status`, `user_created_tour_id`) VALUES ('1', 'Khách sạn Amazing Sapa', '1', 'congnt96', 'tiencong.ktqd@gmail.com', 'pending', '12')
ERROR - 2018-01-03 16:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 16:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 16:57:26 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 170
ERROR - 2018-01-03 16:57:26 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 170
ERROR - 2018-01-03 17:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 17:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 17:03:02 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 170
ERROR - 2018-01-03 17:03:02 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\model-crud\Crud_manager.php 170
ERROR - 2018-01-03 17:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\Xampp\htdocs\dean\application\views\admin\base_manager\form_item.php 20
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\home.php 1
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 126
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 139
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 145
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 158
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 164
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 177
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 187
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 200
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 206
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 219
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 225
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\home.php 238
ERROR - 2018-01-03 18:23:53 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\home.php 316
ERROR - 2018-01-03 18:25:05 --> Severity: Notice --> Undefined variable: path_image E:\Xampp\htdocs\dean\application\views\homepage\layout_login_register.php 7
ERROR - 2018-01-03 18:29:53 --> Severity: Notice --> Undefined variable: get_user E:\Xampp\htdocs\dean\application\views\first_login\form_place.php 13
ERROR - 2018-01-03 18:30:04 --> Severity: Notice --> Undefined variable: get_user E:\Xampp\htdocs\dean\application\views\first_login\form_place.php 13
ERROR - 2018-01-03 18:34:15 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `users` (`username`, `email`, `role_id`, `password`, `first_login`) VALUES (NULL, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e', '0')
ERROR - 2018-01-03 18:34:24 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `users` (`username`, `email`, `role_id`, `password`, `first_login`) VALUES (NULL, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e', '0')
ERROR - 2018-01-03 18:53:55 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `users` (`username`, `email`, `role_id`, `password`, `first_login`) VALUES (NULL, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e', '0')
ERROR - 2018-01-03 18:58:25 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `users` (`username`, `email`, `role_id`, `password`, `first_login`) VALUES (NULL, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e', '0')
