<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-27 18:49:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-27 18:49:03 --> Unable to connect to the database
ERROR - 2018-05-27 18:49:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-05-27 18:49:03 --> Unable to connect to the database
