<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-16 04:49:56 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 159
ERROR - 2018-06-16 17:23:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-06-16 17:23:33 --> Unable to connect to the database
ERROR - 2018-06-16 17:23:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\websitethanh\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-06-16 17:23:42 --> Unable to connect to the database
