<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-13 11:48:00 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 11:48:38 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 11:49:44 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 11:49:54 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 11:50:46 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 11:50:51 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 12:01:40 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 77
ERROR - 2018-06-13 16:40:23 --> Severity: Notice --> Undefined property: Cart::$m_categories_management E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 57
ERROR - 2018-06-13 16:40:23 --> Severity: Error --> Call to a member function get_all() on null E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 57
ERROR - 2018-06-13 16:40:30 --> Severity: Notice --> Undefined property: Cart::$m_categories_management E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 57
ERROR - 2018-06-13 16:40:30 --> Severity: Error --> Call to a member function get_all() on null E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 57
ERROR - 2018-06-13 17:56:22 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 35
ERROR - 2018-06-13 17:56:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\controllers\Cart.php 35
