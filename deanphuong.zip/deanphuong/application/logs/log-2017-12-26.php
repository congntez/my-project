<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-26 16:20:11 --> Severity: Warning --> Missing argument 1 for Home::book_tour() E:\Xampp\htdocs\dean\application\controllers\Home.php 86
ERROR - 2017-12-26 16:20:11 --> Severity: Notice --> Undefined variable: tour_id E:\Xampp\htdocs\dean\application\controllers\Home.php 89
ERROR - 2017-12-26 16:20:11 --> Severity: Notice --> Undefined variable: tour_id E:\Xampp\htdocs\dean\application\controllers\Home.php 93
ERROR - 2017-12-26 16:20:11 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Home.php 96
ERROR - 2017-12-26 16:20:11 --> Severity: Notice --> Undefined property: Home::$M_user_book_tour E:\Xampp\htdocs\dean\application\controllers\Home.php 99
ERROR - 2017-12-26 16:20:11 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 99
ERROR - 2017-12-26 16:20:46 --> Severity: Warning --> Missing argument 1 for Home::book_tour() E:\Xampp\htdocs\dean\application\controllers\Home.php 86
ERROR - 2017-12-26 16:20:46 --> Severity: Notice --> Undefined variable: tour_id E:\Xampp\htdocs\dean\application\controllers\Home.php 88
ERROR - 2017-12-26 16:20:58 --> Severity: Warning --> Missing argument 1 for Home::book_tour() E:\Xampp\htdocs\dean\application\controllers\Home.php 86
ERROR - 2017-12-26 16:20:58 --> Severity: Notice --> Undefined variable: tour_id E:\Xampp\htdocs\dean\application\controllers\Home.php 88
ERROR - 2017-12-26 16:23:17 --> Severity: Notice --> Undefined property: Home::$M_user_book_tour E:\Xampp\htdocs\dean\application\controllers\Home.php 103
ERROR - 2017-12-26 16:23:17 --> Severity: Error --> Call to a member function insert() on null E:\Xampp\htdocs\dean\application\controllers\Home.php 103
ERROR - 2017-12-26 16:24:20 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `user_book_tour` (`tour_id`, `user_book_id`, `status`, `user_created_tour_id`) VALUES ('19', '1', 'pending', '12')
