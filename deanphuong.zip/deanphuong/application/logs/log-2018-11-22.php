<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-22 03:01:43 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\libraries\Session\drivers\Session_files_driver.php 212
ERROR - 2018-11-22 03:01:43 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2018-11-22 03:01:43 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\tienc\AppData\Local\Temp) Unknown 0
ERROR - 2018-11-22 04:47:53 --> Severity: Error --> Maximum execution time of 30 seconds exceeded E:\Xampp_7.2\htdocs\deanphuong\vendor\codeigniter\framework\system\libraries\Session\drivers\Session_files_driver.php 212
ERROR - 2018-11-22 04:47:53 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2018-11-22 04:47:53 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\Users\tienc\AppData\Local\Temp) Unknown 0
ERROR - 2018-11-22 04:48:05 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 38
ERROR - 2018-11-22 04:48:39 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:39 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:39 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:39 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:39 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:39 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:39 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:39 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Creating default object from empty value E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Creating default object from empty value E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'old_price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 25
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Trying to get property 'price' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 26
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Division by zero E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 27
ERROR - 2018-11-22 04:48:40 --> Severity: Warning --> Attempt to assign property 'sale' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\controllers\Product_detail.php 28
ERROR - 2018-11-22 04:48:40 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 38
ERROR - 2018-11-22 04:50:35 --> Severity: Notice --> Undefined variable: values_product E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 32
ERROR - 2018-11-22 04:50:35 --> Severity: Notice --> Trying to get property 'images' of non-object E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\products_detail.php 32
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
ERROR - 2018-11-22 04:51:19 --> Severity: Notice --> Undefined property: stdClass::$sale E:\Xampp_7.2\htdocs\deanphuong\application\views\homepage\all_collection.php 41
