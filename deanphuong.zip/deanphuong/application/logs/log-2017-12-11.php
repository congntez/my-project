<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-11 15:52:36 --> Query error: Unknown column 'active' in 'field list' - Invalid query: SELECT `email`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
WHERE `email` = 'congnt'
AND `deleted` =0
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2017-12-11 15:52:37 --> Query error: Unknown column 'active' in 'field list' - Invalid query: SELECT `email`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
WHERE `email` = 'congnt'
AND `deleted` =0
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2017-12-11 15:52:38 --> Query error: Unknown column 'active' in 'field list' - Invalid query: SELECT `email`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
WHERE `email` = 'congnt'
AND `deleted` =0
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2017-12-11 15:52:38 --> Query error: Unknown column 'active' in 'field list' - Invalid query: SELECT `email`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
WHERE `email` = 'congnt'
AND `deleted` =0
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2017-12-11 15:52:38 --> Query error: Unknown column 'active' in 'field list' - Invalid query: SELECT `email`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
WHERE `email` = 'congnt'
AND `deleted` =0
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2017-12-11 15:59:54 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 15:59:54 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 16:06:59 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 16:13:53 --> Severity: Notice --> Undefined variable: login_url E:\Xampp\htdocs\dean\application\views\admin\demo_login\content.php 28
ERROR - 2017-12-11 16:34:35 --> Query error: Table 'dean.product' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `product` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-11 16:34:45 --> Query error: Table 'dean.product' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `product` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-11 16:35:51 --> Query error: Table 'dean.product' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `product` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-11 16:36:02 --> Query error: Table 'dean.product' doesn't exist - Invalid query: SELECT *
FROM `product` AS `m`
WHERE `m`.`deleted` =0
ERROR - 2017-12-11 16:46:37 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 16:46:37 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 16:46:47 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 16:46:47 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:01:21 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:01:21 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:30:38 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:30:38 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:32:58 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:32:58 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:33:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-11 17:33:11 --> Severity: Notice --> Undefined property: stdClass::$role_name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
