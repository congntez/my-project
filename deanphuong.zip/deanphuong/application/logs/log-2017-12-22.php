<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:04:21 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:05:08 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 30
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:22 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:09:23 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\homepage\register.php 32
ERROR - 2017-12-22 16:18:00 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' E:\Xampp\htdocs\dean\application\views\homepage\register.php 27
ERROR - 2017-12-22 16:18:08 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\register.php 27
ERROR - 2017-12-22 16:55:12 --> Query error: Table 'dean.customer' doesn't exist - Invalid query: SELECT *
FROM `customer`
WHERE `username` = '123123123'
ERROR - 2017-12-22 16:56:17 --> Severity: Warning --> Missing argument 4 for M_register::insert_user(), called in E:\Xampp\htdocs\dean\application\controllers\Register.php on line 47 and defined E:\Xampp\htdocs\dean\application\models\M_register.php 9
ERROR - 2017-12-22 16:56:17 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_register.php 13
ERROR - 2017-12-22 17:14:19 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:19 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:21 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:21 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:22 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:22 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:22 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:22 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:22 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:22 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:22 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:22 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:22 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:22 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:23 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:23 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:14:23 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:14:23 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:44:00 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:44:00 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:44:01 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:44:01 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:44:01 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:44:01 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 17:44:02 --> Severity: Warning --> Missing argument 2 for M_login::check_pass(), called in E:\Xampp\htdocs\dean\application\controllers\Login.php on line 43 and defined E:\Xampp\htdocs\dean\application\models\M_login.php 39
ERROR - 2017-12-22 17:44:02 --> Severity: Notice --> Undefined variable: role_id E:\Xampp\htdocs\dean\application\models\M_login.php 49
ERROR - 2017-12-22 18:11:23 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:11:24 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:11:24 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:11:24 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:11:24 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:11:25 --> Severity: Notice --> Undefined variable: side_bar_admin E:\Xampp\htdocs\dean\application\views\admin\base_layout\layout_body.php 16
ERROR - 2017-12-22 18:22:26 --> Severity: Notice --> Undefined property: Hotel::$m_room_management E:\Xampp\htdocs\dean\application\controllers\Hotel.php 39
ERROR - 2017-12-22 18:22:26 --> Severity: Error --> Call to a member function get() on null E:\Xampp\htdocs\dean\application\controllers\Hotel.php 39
