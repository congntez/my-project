<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-10 16:24:37 --> Severity: Notice --> Undefined variable: place E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:25:20 --> Severity: Notice --> Undefined variable: place E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:25:23 --> Severity: Notice --> Undefined variable: place E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:26:07 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:26:07 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:26:07 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:26:07 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:27:23 --> Severity: Notice --> Undefined variable: place E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:28:37 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:28:37 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:28:37 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:28:37 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:29:53 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:29:53 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:29:53 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:29:53 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:31:33 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:31:33 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:31:33 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:32:01 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:32:01 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:32:01 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:37:31 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\place.php 4
ERROR - 2017-12-10 16:37:31 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:37:31 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:37:31 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 16:39:37 --> Severity: Notice --> Array to string conversion E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 10
ERROR - 2017-12-10 16:39:37 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 16:39:37 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 16:39:37 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 17:06:24 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 17:06:24 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 17:06:24 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 17:07:16 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 17:07:16 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 17:07:16 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 17:11:20 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 17:11:20 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 17:11:20 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 17:14:53 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 17:14:53 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 17:14:53 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-10 17:16:18 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-10 17:16:18 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-10 17:16:18 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
