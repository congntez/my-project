<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-29 18:43:19 --> Severity: Warning --> Missing argument 1 for Home::order_success() E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 104
