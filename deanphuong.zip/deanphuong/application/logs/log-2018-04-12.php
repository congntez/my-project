<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:25:54 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:28:05 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:28:05 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 05:28:05 --> Severity: Notice --> Undefined property: stdClass::$first_login E:\Xampp\htdocs\minhtrishop\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-04-12 18:12:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-04-12 18:12:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\minhtrishop\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-04-12 18:12:14 --> Unable to connect to the database
ERROR - 2018-04-12 18:12:14 --> Unable to connect to the database
