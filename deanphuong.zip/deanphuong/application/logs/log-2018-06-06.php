<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-06 18:40:21 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:21 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:21 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:21 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 18:40:42 --> Severity: Notice --> Undefined property: stdClass::$cat_id E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:20 --> Severity: Notice --> Undefined property: stdClass::$status E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 19:31:46 --> Severity: Notice --> Undefined property: stdClass::$Lựa chọn hiển thị E:\Xampp\htdocs\websitethanh\application\views\admin\base_manager\table_data.php 53
ERROR - 2018-06-06 20:15:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 93
ERROR - 2018-06-06 20:15:56 --> Severity: Notice --> Undefined property: stdClass::$description E:\Xampp\htdocs\websitethanh\application\views\homepage\products_detail.php 99
