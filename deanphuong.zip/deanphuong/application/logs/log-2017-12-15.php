<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-15 08:26:08 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 6
ERROR - 2017-12-15 08:26:23 --> Severity: Notice --> Undefined variable: user E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 6
ERROR - 2017-12-15 08:27:26 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 6
ERROR - 2017-12-15 08:29:44 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 8
ERROR - 2017-12-15 08:35:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 7
ERROR - 2017-12-15 08:36:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\test.php 7
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:02 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 08:56:24 --> Severity: Warning --> Missing argument 1 for Place::detail() E:\Xampp\htdocs\dean\application\controllers\Place.php 48
ERROR - 2017-12-15 08:56:24 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-15 08:56:24 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-15 08:56:24 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-15 08:57:18 --> Severity: Warning --> Missing argument 1 for Place::detail() E:\Xampp\htdocs\dean\application\controllers\Place.php 48
ERROR - 2017-12-15 08:57:18 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-15 08:57:18 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-15 08:57:18 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-15 08:58:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\controllers\Place.php 55
ERROR - 2017-12-15 08:58:49 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Place.php 55
ERROR - 2017-12-15 08:58:53 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\controllers\Place.php 55
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:03:40 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:04:28 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\views\homepage\place\all_categories.php 43
ERROR - 2017-12-15 09:15:21 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\Xampp\htdocs\dean\application\controllers\Place.php 44
ERROR - 2017-12-15 09:15:38 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\Xampp\htdocs\dean\application\controllers\Place.php 44
ERROR - 2017-12-15 09:15:54 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\Xampp\htdocs\dean\application\controllers\Place.php 45
ERROR - 2017-12-15 09:19:34 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\controllers\Place.php 33
ERROR - 2017-12-15 09:20:19 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\controllers\Place.php 33
ERROR - 2017-12-15 09:21:21 --> Severity: Notice --> Undefined variable: id E:\Xampp\htdocs\dean\application\controllers\Place.php 38
ERROR - 2017-12-15 09:43:22 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-15 09:43:22 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-15 09:43:22 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-15 09:44:04 --> Severity: Notice --> Undefined variable: menu E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 1
ERROR - 2017-12-15 09:44:04 --> Severity: Notice --> Undefined variable: link_register E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 13
ERROR - 2017-12-15 09:44:04 --> Severity: Notice --> Undefined variable: ft E:\Xampp\htdocs\dean\application\views\homepage\place_layout.php 22
ERROR - 2017-12-15 09:44:52 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE), expecting function (T_FUNCTION) E:\Xampp\htdocs\dean\application\controllers\Place.php 50
