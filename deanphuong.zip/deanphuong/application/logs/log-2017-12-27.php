<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:05 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:12 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:30 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:56:50 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 202
ERROR - 2017-12-27 07:57:31 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 150
ERROR - 2017-12-27 07:57:31 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 150
ERROR - 2017-12-27 07:57:31 --> Severity: Notice --> Undefined property: stdClass::$images E:\Xampp\htdocs\dean\application\models\M_room_management.php 150
ERROR - 2017-12-27 08:12:07 --> Severity: Notice --> Undefined variable: tour_detail E:\Xampp\htdocs\dean\application\views\homepage\hotel\detail.php 49
ERROR - 2017-12-27 08:12:07 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\homepage\hotel\detail.php 49
ERROR - 2017-12-27 09:18:05 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-27 09:18:05 --> Severity: Notice --> Undefined property: stdClass::$name E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 52
ERROR - 2017-12-27 09:22:04 --> Severity: Error --> Call to undefined method User_management::_set_side_bar_admin() E:\Xampp\htdocs\dean\application\controller-layout\Admin_layout.php 20
ERROR - 2017-12-27 09:22:17 --> Severity: Error --> Call to undefined method User_management::_set_side_bar_admin() E:\Xampp\htdocs\dean\application\controller-layout\Admin_layout.php 20
ERROR - 2017-12-27 09:22:30 --> Severity: Error --> Call to undefined method User_management::_set_top_bar() E:\Xampp\htdocs\dean\application\controller-layout\Admin_layout.php 20
ERROR - 2017-12-27 09:22:40 --> Severity: Error --> Call to undefined method User_management::_set_top_bar() E:\Xampp\htdocs\dean\application\controller-layout\Admin_layout.php 20
ERROR - 2017-12-27 09:22:43 --> Severity: Error --> Call to undefined method Place_management::_set_top_bar() E:\Xampp\htdocs\dean\application\controller-layout\Admin_layout.php 20
ERROR - 2017-12-27 10:13:25 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Upload.php 412
ERROR - 2017-12-27 10:15:04 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\libraries\Upload.php 412
ERROR - 2017-12-27 10:16:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ']' E:\Xampp\htdocs\dean\application\models\M_room_management.php 164
ERROR - 2017-12-27 11:58:44 --> Severity: Parsing Error --> syntax error, unexpected ']' E:\Xampp\htdocs\dean\application\controllers\User_management.php 13
ERROR - 2017-12-27 11:58:56 --> Severity: Parsing Error --> syntax error, unexpected ',' E:\Xampp\htdocs\dean\application\controllers\User_management.php 13
