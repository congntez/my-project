<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-05 02:23:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-01-05 02:23:34 --> Unable to connect to the database
ERROR - 2018-01-05 05:15:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 E:\Xampp\htdocs\dean\vendor\codeigniter\framework\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2018-01-05 05:15:11 --> Unable to connect to the database
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> array_splice() expects parameter 1 to be array, object given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 40
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 42
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:41:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 56
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:17 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:55 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:55 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:55 --> Severity: Error --> Cannot access empty property E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
ERROR - 2018-01-05 05:43:59 --> Severity: Warning --> array_splice() expects parameter 1 to be array, string given E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:59 --> Severity: Warning --> implode(): Invalid arguments passed E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 51
ERROR - 2018-01-05 05:43:59 --> Severity: Error --> Cannot access empty property E:\Xampp\htdocs\dean\application\views\admin\base_manager\table_data.php 54
