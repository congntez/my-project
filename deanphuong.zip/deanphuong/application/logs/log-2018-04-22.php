<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-22 09:25:54 --> Severity: Notice --> Undefined property: Home::$m_tour_management E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 21
ERROR - 2018-04-22 09:25:54 --> Severity: Error --> Call to a member function get_by() on null E:\Xampp\htdocs\minhtrishop\application\controllers\Home.php 21
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:32:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:34:06 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:35:48 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 40
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:25 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:36:41 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 44
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:39 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:37:58 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 43
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:38:34 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:39:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 39
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:41:57 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:43:50 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 42
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:54:56 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 45
ERROR - 2018-04-22 09:55:46 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:55:46 --> Severity: Warning --> Attempt to assign property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 38
ERROR - 2018-04-22 09:55:46 --> Severity: Notice --> Undefined variable: values E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 40
ERROR - 2018-04-22 09:57:16 --> Severity: Notice --> Trying to get property of non-object E:\Xampp\htdocs\minhtrishop\application\views\homepage\home.php 40
